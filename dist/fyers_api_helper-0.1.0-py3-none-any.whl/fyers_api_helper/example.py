def addOne(num):
    num = num + 1
    return num
